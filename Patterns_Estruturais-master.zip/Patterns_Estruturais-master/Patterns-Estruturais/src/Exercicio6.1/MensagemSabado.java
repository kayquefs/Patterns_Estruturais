package Exercicio6_1;

public class MensagemSabado implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � s�bado.");
	}
}
