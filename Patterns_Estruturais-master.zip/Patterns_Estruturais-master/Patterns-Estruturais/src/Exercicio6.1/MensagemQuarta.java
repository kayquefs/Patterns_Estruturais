package Exercicio6_1;

public class MensagemQuarta implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � quarta-feira.");
	}
}
