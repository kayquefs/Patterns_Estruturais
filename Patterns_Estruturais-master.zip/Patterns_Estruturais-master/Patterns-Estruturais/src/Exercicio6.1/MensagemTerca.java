package Exercicio6_1;

public class MensagemTerca implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � ter�a-feira.");
	}
}
